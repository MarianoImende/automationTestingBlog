---
#title: "Articulos sobre testing"
description: "Tecnicas y novedades sobre el mundo del testing de softwate"
# 1. To ensure Netlify triggers a build on our exampleSite instance, we need to change a file in the exampleSite directory.
cascade:
featured_image: "/images/posts.jpg"

---